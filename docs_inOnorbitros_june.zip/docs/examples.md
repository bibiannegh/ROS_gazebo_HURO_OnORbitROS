# Examples of Applications using OnOrbitROS

In this section you can find different examples that exploit OnOrbitROS functionalities. They can serve as a guide to develop your own application, based on these or from scratch.

---

## Launch the examples

To launch the examples simply launch the following command, as you would with any other ROS package: 

    roslaunch <your_project_name> <your_launch_file>

---

## ETS VII

More information to come